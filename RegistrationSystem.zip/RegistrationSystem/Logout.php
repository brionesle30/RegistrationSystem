
<?php require 'connections/connections.php'; ?>
<?php 

session_start();
unset($_SESSION["UserID"]);
session_destroy();

 ?>
<?php

	if(isset($_POST['LoginButton'])) {
		
		$USN = $_POST['UsernameF'];
		$PW = $_POST['PasswordF'];
		
		$result = $con->query("SELECT * FROM user_tbl WHERE Username='$USN' AND Password='$PW'");
		
		$row = $result->fetch_array(MYSQLI_BOTH);
		
		@session_start();
		$_SESSION["UserID"] = $row['UserID'];
		
		@header('Location: Account.php');
		}
		
?>
 <!doctype html>
<html>
<head>
<link href="css/master.css" rel="stylesheet"type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<div class="Container">
		<div class="Header"></div>
        <div class="Menu">
        <div id='cssmenu'>
<ul>
   <li class='active'><a href=''><span>Home</span></a></li>
   <li><a href='#'><span>Register</span></a></li>
   <li><a href="Login.php"><span>LogIn</span></a></li>
   <li class='last'><a href='#'><span>About Us</span></a></li>
</ul>
		</div>
</div>
        <div class="LeftBody"></div>
        <div class="RightBody"><h3>You have Logged out!!!</h3>
        <form id="form1" name="form1" method="post">
           <div class="FormElement">
             <input name="UsernameF" type="text" required="required" class="TField" id="LoginF" placeholder="Username">
           </div>
           <div class="FormElement">
             <input name="PasswordF" type="password" required="required" class="TField" id="passwordF">
           </div>
           <div class="FormElement">
             <input name="LoginButton" type="submit" class="button" id="LoginButton" value="Login">
           </div>
          </form>
        
        </div>
        
        <div class="Footer"></div>
	</div>
</body>
</html>